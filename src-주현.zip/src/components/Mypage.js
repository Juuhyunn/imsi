import React from 'react';

const Mypage = () => (
    <>
    <div>
        <h1>여기는 마이페이지</h1>
        <img src="./images/pet.png" alt=""/>
        <h3>이름은 이것입니다.</h3>
        <a href="#">회원 정보 수정하기</a>
    </div>
    </>
)
export default Mypage