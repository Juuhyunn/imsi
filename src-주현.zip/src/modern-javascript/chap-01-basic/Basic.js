import React from 'react';

var man = {} //es5


const Basic = () => {
    const letSample = () => {
        let tom = "Tom" //es6에서 variable
        const james = "James" //es6에서 constant
    }
    const dynamictype = () => {
        let userId = 12;
        // console.log("USER ID is "+ userId) // --> Template String
        console.log(`USER ID is ${userId}`)  // --> Template String
    }
    return (
        <>
        <button onClick={dynamictype}>다이나믹 타입 테스트</button>
        </>
    )
}
export default Basic