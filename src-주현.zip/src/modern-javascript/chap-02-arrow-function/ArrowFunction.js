import React from 'react';

const ArrowFunction = () => {
    return (
        <>
        </>
    )
}
export default ArrowFunction