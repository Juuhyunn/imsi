import React from 'react';

const Arguments = () => {
    return (
        <>
        </>
    )
}
export default Arguments